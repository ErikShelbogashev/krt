
/*
 * Copyright 2015-2023 the original author or authors.
 *
 * All rights reserved. This program and the accompanying materials are
 * made available under the terms of the Eclipse Public License v2.0 which
 * accompanies this distribution and is available at
 *
 * https://www.eclipse.org/legal/epl-v20.html
 */
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;

/**
 * Simple test case that is used to verify proper support for classpath scanning
 * within the <em>default</em> package.
 *
 * @since 5.0
 */
@Disabled("Only used reflectively by other tests")
class DefaultPackageTestCase {

	@Test
	void test() {
		// do nothing
	}

}
